# OOO-Assistant

Team: Wasfi, Navjot, Amanda, Toni
